-- Speak for someone else :)
function say_as(who, what)
        msg_broadcast(0, "\255g[\255o"..who.."\255g] \255B"..what)
end
